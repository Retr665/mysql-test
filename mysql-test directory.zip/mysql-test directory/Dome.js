var express = require('express');   //引入express模块
var mysql = require('mysql');     //引入mysql模块
var app = express();        //创建express的实例
 
var connection = mysql.createConnection({      //创建mysql实例
    host:'127.0.0.1',
    port:'3306',
    user:'root',
    password:'Kaopu@090729',
    database:'Dome'
});

connection.connect();
var sql = 'SELECT users.username, users.email, users.birth_date, badge_types.badge_name FROM badge_logs JOIN badge_types JOIN users ON badge_logs.badgetype_id = badge_types.badge_type_id AND badge_logs.user_id = users.user_id;';
var str = " ";
connection.query(sql, function (err,result) {
    if(err){
        console.log('[SELECT ERROR]:',err.message);
    }
    str += "<table>";
result.forEach((row)=>{str+="<tr>"+"<td>"+ row.username + "</td>" + "<td>" + row.email + "</td>" + "<td>" + row.badge_name + "</td>" + "</tr>"});
str +="</table>";
    //数据库查询的数据保存在result中，但浏览器并不能直接读取result中的结果，因此需要用JSON进行解析
    //console.log(result);   //数据库查询结果返回到result中
    console.log(str);
});
app.get('/',function (req,res) {
    res.send(str);  //服务器响应请求
});
connection.end();
app.listen(3000,function () {    ////监听3000端口
});