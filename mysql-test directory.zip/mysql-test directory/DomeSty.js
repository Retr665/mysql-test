// JavaScript Document

var icon = document.getElementById("icon_img");

icon.src = "images/user1.png";